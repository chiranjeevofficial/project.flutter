package com.example.whatsapp_messanger

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
