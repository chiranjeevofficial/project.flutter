import 'package:flutter/material.dart';
import 'package:shared_prefs/preferences/shared_prefs.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: const Text('Home Page'),
        ),
        body: FutureBuilder<String?>(
            future: SharedPreferencesService.getData(PrefKey.username),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const Center(
                  child: CircularProgressIndicator(),
                );
              } else if (snapshot.hasError) {
                return Center(
                  child: Text('Error: ${snapshot.error}'),
                );
              } else {
                String username =
                    snapshot.data ?? 'Unknown'; // Default value if data is null
                return Column(
                  children: [
                    Text(
                      'Username: $username',
                    ),
                  ],
                );
              }
            }));
  }
}
