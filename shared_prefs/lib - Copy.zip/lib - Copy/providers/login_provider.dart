import 'package:flutter/material.dart';

class LoginProvider extends ChangeNotifier {
  String _username = '';
  String _password = '';
  String? _usernameError;
  String? _passwordError;

  String get username => _username;
  String? get password => _password;
  String? get usernameError => _usernameError;
  String? get passwordError => _passwordError;

  void setUsername(String value) {
    _username = value;
    _usernameError = null;
    notifyListeners();
  }

  void setPassword(String value) {
    _password = value;
    _passwordError = null;
    notifyListeners();
  }

  void validateUsername(String value) {
    if (value.isEmpty) {
      _usernameError = 'Username is not empty';
      notifyListeners();
    } else if (value.length < 8) {
      _usernameError = 'Username length at least 8';
      notifyListeners();
    } else {
      _usernameError = null;
      notifyListeners();
    }
  }

  void validatePassword(String value) {
    if (value.isEmpty) {
      _passwordError = 'Password is not empty';
      notifyListeners();
    } else if (value.length < 8) {
      _passwordError = 'Password length at least 8';
      notifyListeners();
    } else if (!value.contains(RegExp(r'[!@#$%^&*]'))) {
      _passwordError = 'Password must contain special symbols !@#\$%^&*';
      notifyListeners();
    } else {
      _passwordError = null;
      notifyListeners();
    }
  }
}
